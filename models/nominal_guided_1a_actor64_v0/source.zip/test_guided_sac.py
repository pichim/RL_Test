"""Regression checks for guided SAC's symmetry and reward boundaries."""

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import gymnasium as gym
import numpy as np
import torch

from furuta_env import FurutaSwingUpEnv, matlab_reward
from guided_sac import EnergyShaping, REFLECTION, ReflectedPolicy, teacher_bounds, teacher_examples
from nominal import CONFIG, run


class EnergyFixture(gym.Env):
    def reset(self, **kwargs):
        return None, {"energy_error": 1.0}

    def step(self, action):
        terminated, truncated = action
        return None, 2.0, terminated, truncated, {"energy_error": 0.5}


class GuidedSACTests(unittest.TestCase):
    def test_exact_actor_and_critic_reflection(self):
        obs_space = gym.spaces.Box(-1.0, 1.0, shape=(7,), dtype=np.float32)
        act_space = gym.spaces.Box(-1.0, 1.0, shape=(1,), dtype=np.float32)
        policy = ReflectedPolicy(obs_space, act_space, lambda _: 0.001, net_arch=[8])
        rng = torch.Generator().manual_seed(1)
        observation = torch.rand(8, 7, generator=rng) * 2 - 1
        action = torch.rand(8, 1, generator=rng) * 2 - 1
        mirror = observation * torch.tensor(REFLECTION)
        mean, scale, _ = policy.actor.get_action_dist_params(observation)
        mirror_mean, mirror_scale, _ = policy.actor.get_action_dist_params(mirror)
        torch.testing.assert_close(mean, -mirror_mean, rtol=0, atol=0)
        torch.testing.assert_close(scale, mirror_scale, rtol=0, atol=0)
        torch.testing.assert_close(
            policy.critic(observation, action), policy.critic(mirror, -action), rtol=0, atol=0,
        )
        equilibrium = torch.tensor([[0., 1., 0., 0., 1., 0., 0.]])
        self.assertEqual(policy.actor(equilibrium, deterministic=True).item(), 0.0)

    def test_energy_potential_terminal_and_timeout(self):
        for terminated, truncated in ((False, False), (True, False), (False, True)):
            with self.subTest(terminated=terminated, truncated=truncated):
                env = EnergyShaping(EnergyFixture(), gamma=0.99, weight=0.25)
                env.reset()
                _, reward, *_ = env.step((terminated, truncated))
                successor = 0.0 if terminated else -0.25 * 0.25 / 1.25
                self.assertAlmostEqual(reward, 2.0 + 0.99 * successor + 0.125)

    def test_teacher_samples_are_local_and_current_limited(self):
        observations, actions = teacher_examples(CONFIG, 0)
        self.assertGreater(len(actions), 192)
        self.assertEqual(observations.shape, (len(actions), 7))
        self.assertTrue(np.isfinite(observations).all())
        self.assertTrue((np.abs(actions) <= 1.0).all())
        # The early samples deliberately vary the previous command.
        self.assertGreater(np.std(observations[:, -1]), 0.01)

    def test_guided_one_amp_preserves_penalties_and_command_units(self):
        with (
            TemporaryDirectory() as directory,
            patch("nominal.cuda_preflight", return_value=None),
            patch("nominal.train_guided", side_effect=RuntimeError("capture config")) as train,
        ):
            with self.assertRaisesRegex(RuntimeError, "capture config"):
                run(Path(directory) / "pilot", execute=True, guided=True, max_current=1.0)
            config = train.call_args.args[0]
        self.assertEqual(config.max_current, 1.0)
        self.assertEqual(config.current_weight, 4.0)
        self.assertEqual(config.action_change_weight, 12.0)
        env = FurutaSwingUpEnv(config)
        for expected in (-1.0, 1.0):
            env.reset(options={"initial_state": [0.0, np.pi, 0.0, 0.0]})
            _, _, _, _, info = env.step(np.array([expected], dtype=np.float32))
            self.assertEqual(info["command_current"], expected)
            self.assertEqual(info["current"], expected)
        np.testing.assert_array_equal(teacher_bounds(config), [0.2, 0.1, 0.5, 1.0])
        upright = np.array([0.0, np.pi, 0.0, 0.0])
        baseline = matlab_reward(upright, 0.8, -0.4, CONFIG)
        one_amp = matlab_reward(upright, 0.4, -0.2, config)
        self.assertAlmostEqual(baseline, one_amp)
