"""Train one nominal direct-current SAC controller and evaluate its best model."""

from __future__ import annotations

import argparse
import csv
import math
from dataclasses import asdict, replace
from datetime import datetime, timezone
from pathlib import Path
import shutil
from time import perf_counter
import traceback

import torch

from evaluate import main as evaluate
from furuta_env import DEFAULT_CONFIG
from guided_sac import train_guided
from train import atomic_write_json, train


DEFAULT_JOB = Path(__file__).resolve().parent / "runs" / "nominal_sac_actor64_seed0_v0"
CONFIG = replace(
    DEFAULT_CONFIG,
    current_filter_cutoff_hz=0.0,
    current_filter_cutoff_randomization_hz=0.0,
    current_filter_cutoff_min_hz=0.0,
    current_filter_cutoff_max_hz=0.0,
    action_dead_time_max_samples=0,
    training_parameter_randomization=False,
    motor_torque_randomization=0.0,
    arm_mass_randomization=0.0,
    arm_inertia_randomization=0.0,
    pendulum_mass_randomization=0.0,
    pendulum_inertia_randomization=0.0,
    arm_damping_randomization=0.0,
    pendulum_damping_randomization=0.0,
)


def cuda_preflight() -> dict:
    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA is unavailable. Use the CUDA-enabled rl-env interpreter "
            "and make sure the NVIDIA GPU is visible to this process."
        )
    sample = torch.ones((8, 8), device="cuda")
    if (sample @ sample)[0, 0].item() != 8.0:
        raise RuntimeError("CUDA preflight matrix multiplication returned an unexpected result.")
    return {
        "device": torch.cuda.get_device_name(),
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
    }


def run(
    job: Path = DEFAULT_JOB,
    execute: bool = False,
    action_change_weight: float = CONFIG.action_change_weight,
    *,
    task_config=None,
    require_cuda: bool = False,
    guided: bool = False,
    energy_weight: float | None = None,
    max_current: float | None = None,
    timesteps: int = 2_000_000,
    seed: int = 0,
) -> None:
    if max_current is not None and (not guided or max_current not in (0.5, 1.0)):
        raise ValueError("Choose a guided current limit of 0.5 A or 1 A.")
    if energy_weight is not None and (
        not guided or not math.isfinite(energy_weight) or energy_weight < 0
    ):
        raise ValueError("Energy weight must be finite and nonnegative, and requires --guided.")
    if timesteps <= 0 or timesteps % 2 or not 0 <= seed < 2**32:
        raise ValueError("Choose a positive even timestep budget and a seed in [0, 2**32).")
    if guided and task_config is not None:
        raise ValueError("Guided SAC is defined on the centered nominal task.")
    if guided and energy_weight is None:
        energy_weight = 0.25
    job = job.resolve()
    config = replace(
        CONFIG if task_config is None else task_config,
        action_change_weight=action_change_weight,
    )
    if max_current is not None:
        # The reward uses normalized commands. Preserve the cost per ampere squared.
        cost_scale = (max_current / CONFIG.max_current) ** 2
        config = replace(
            config,
            max_current=max_current,
            current_weight=config.current_weight * cost_scale,
            action_change_weight=config.action_change_weight * cost_scale,
        )
    settings = {
        "seed": seed,
        "total_timesteps": timesteps,
        "gamma": 0.99,
        "actor_network": [64, 64],
        "critic_network": [64, 64],
        "evaluation_episodes": 50,
    }
    print(
        f"Nominal SAC: {settings}\n"
        f"Current limit: ±{config.max_current:g} A. "
        f"Normalized current and action-change weights: {config.current_weight:g}, {config.action_change_weight:g}.\n"
        f"Output: {job}",
        flush=True,
    )
    if job.exists():
        raise FileExistsError(f"Choose a fresh job directory: {job}")
    if guided:
        print(f"Guided SAC with reflected policy and critics, LQR teaching, and energy weight {energy_weight:g}.", flush=True)
    cuda = cuda_preflight() if require_cuda or guided else None
    if cuda is not None:
        print(
            f"CUDA preflight passed on {cuda['device']} (PyTorch {cuda['torch_version']}).",
            flush=True,
        )
    if not execute:
        print("Dry run. Add --execute to train and evaluate.", flush=True)
        return
    job.mkdir(parents=True)
    phase = "training"
    timings: dict[str, float] = {}

    def status(state: str, **details) -> None:
        atomic_write_json(job / "status.json", {
            "state": state,
            "phase": phase,
            "updated_utc": datetime.now(timezone.utc).isoformat(),
            **timings,
            **details,
        })

    try:
        status("running")
        source = job / "source"
        source.mkdir()
        for path in Path(__file__).resolve().parent.glob("*.py"):
            shutil.copy2(path, source / path.name)
        atomic_write_json(job / "experiment.json", {
            "training": settings,
            "config": asdict(config),
            "cuda_preflight": cuda,
            "guided_energy_weight": energy_weight,
            "evaluation": {"controller": "sac", "mode": "nominal", "episodes": 100, "base_seed": 80000},
            "selection": "Fixed nominal training validation; no selection on evaluation seeds.",
        })
        start = perf_counter()
        if guided:
            train_guided(config, job / "training", energy_weight=energy_weight, **settings)
        else:
            train(config=config, run_dir=job / "training", **settings)
        timings["training_seconds"] = perf_counter() - start
        phase = "evaluation"
        status("running")
        start = perf_counter()
        evaluate(
            model_path=job / "training" / "best" / "best_model.zip",
            results_dir=job / "evaluation",
            controller="sac",
            mode="nominal",
            episodes=100,
            base_seed=80000,
        )
        timings["evaluation_seconds"] = perf_counter() - start
        with (job / "evaluation" / "summary.csv").open(newline="", encoding="utf-8") as handle:
            summary = next(csv.DictReader(handle))
        report = (
            "# Nominal SAC Result\n\n"
            f"Current limit: ±{config.max_current:g} A. "
            f"Normalized current and action-change weights: {config.current_weight:g}, {config.action_change_weight:g}.\n\n"
            f"Successes: {summary['success_count']}/{summary['episodes']}. "
            f"Unsafe episodes: {summary['unsafe_count']}. "
            f"Captures: {summary['capture_count']}.\n\n"
            f"Training wall time: {timings['training_seconds']:.1f} s. "
            f"Final evaluation wall time: {timings['evaluation_seconds']:.1f} s.\n\n"
            + (
                "Fixed nominal plant and direct current. LQR supplied training targets. "
                "The standalone actor is saved to training/actor.pt2. "
                if guided else "Fixed nominal plant, direct current, no delay, no LQR. "
            )
            + "Final evaluation uses the learned neural actor. "
            "The policy is selected using training validation, not evaluation seeds.\n\n"
            "Success requires the final second within 5 degrees of upright, "
            f"{config.balance_theta1:g} rad absolute arm position, "
            f"{config.balance_omega1:g} rad/s arm speed, and {config.balance_omega2:g} rad/s pendulum speed. "
            "Initial states still vary across the existing broad reset distribution.\n\n"
            "See evaluation/summary.txt and evaluation/sac/training_nominal for metrics, PNGs, and traces. "
            "One seed and a five-second test do not establish long-duration or hardware reliability.\n"
        )
        (job / "FINDINGS.md").write_text(report, encoding="utf-8")
        phase = "report"
        status("completed", success_count=int(summary["success_count"]), unsafe_count=int(summary["unsafe_count"]))
    except Exception:
        status("failed", error=traceback.format_exc())
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job-dir", type=Path, default=DEFAULT_JOB)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--action-change-weight", type=float, default=CONFIG.action_change_weight)
    parser.add_argument(
        "--require-cuda",
        action="store_true",
        help="verify CUDA before training and fail if it is unavailable",
    )
    parser.add_argument("--guided", action="store_true", help="train reflected SAC with centered LQR targets on CUDA")
    parser.add_argument("--energy-weight", type=float, help="guided potential weight (default: 0.25; 0 for the control run)")
    parser.add_argument(
        "--max-current", type=float, choices=(0.5, 1.0), metavar="AMPS",
        help="guided current limit in A; preserve the baseline physical current penalties",
    )
    parser.add_argument("--timesteps", type=int, default=2_000_000)
    parser.add_argument("--seed", type=int, default=0)
    arguments = parser.parse_args()
    run(
        arguments.job_dir,
        arguments.execute,
        arguments.action_change_weight,
        require_cuda=arguments.require_cuda,
        guided=arguments.guided,
        energy_weight=arguments.energy_weight,
        max_current=arguments.max_current,
        timesteps=arguments.timesteps,
        seed=arguments.seed,
    )
