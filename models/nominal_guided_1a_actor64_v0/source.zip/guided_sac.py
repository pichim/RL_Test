"""Nominal SAC with exact reflection, energy shaping, and LQR supervision."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
from stable_baselines3 import SAC
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.policies import ContinuousCritic
from stable_baselines3.sac.policies import Actor, SACPolicy

from controllers import LQRController
from furuta_env import FurutaSwingUpEnv, observation_from_plant, upright_error
from furuta_model import FurutaPendulum
from train import ResumeStateCallback, SuccessFirstEvalCallback, algorithm_settings, atomic_write_json
from train import runtime_provenance, save_committed_state


# Flip sin(angle), velocity, and previous command. Cosines are even.
REFLECTION = (-1, 1, -1, -1, 1, -1, -1)
TEACHER_BOUNDS = np.array([0.10, 0.05, 0.25, 0.50])
TEACHER_BOUNDS_1A = np.array([0.20, 0.10, 0.50, 1.00])
TEACHER_BATCH = 128
PRETRAIN_UPDATES = 500
TEACHER_LOSS_WEIGHT = 5.0
SLOPE_FRACTION = 0.10
MONITOR_KEYS = ("is_success", "initial_capture", "unsafe")


class ReflectedActor(Actor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.use_sde:
            raise ValueError("The reflected actor uses a squashed Gaussian without gSDE.")
        self.register_buffer("reflection", torch.tensor(REFLECTION, dtype=torch.float32))

    def get_action_dist_params(self, obs):
        pair = torch.cat((obs, obs * self.reflection))
        mean, log_std, kwargs = super().get_action_dist_params(pair)
        direct_mean, mirror_mean = mean.chunk(2)
        direct_scale, mirror_scale = log_std.chunk(2)
        return (direct_mean - mirror_mean) * 0.5, (direct_scale + mirror_scale) * 0.5, kwargs


class ReflectedCritic(ContinuousCritic):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.register_buffer("reflection", torch.tensor(REFLECTION, dtype=torch.float32))

    def forward(self, obs, actions):
        pairs = super().forward(
            torch.cat((obs, obs * self.reflection)), torch.cat((actions, -actions))
        )
        return tuple((direct + mirror) * 0.5 for direct, mirror in (q.chunk(2) for q in pairs))

    def q1_forward(self, obs, actions):
        pair = super().q1_forward(
            torch.cat((obs, obs * self.reflection)), torch.cat((actions, -actions))
        )
        direct, mirror = pair.chunk(2)
        return (direct + mirror) * 0.5


class ReflectedPolicy(SACPolicy):
    def make_actor(self, features_extractor=None):
        kwargs = self._update_features_extractor(self.actor_kwargs, features_extractor)
        return ReflectedActor(**kwargs).to(self.device)

    def make_critic(self, features_extractor=None):
        kwargs = self._update_features_extractor(self.critic_kwargs, features_extractor)
        return ReflectedCritic(**kwargs).to(self.device)


class EnergyShaping(gym.Wrapper):
    def __init__(self, env: FurutaSwingUpEnv, gamma: float, weight: float):
        super().__init__(env)
        self.gamma = gamma
        self.weight = weight
        self.previous_potential = 0.0

    def potential(self, info: dict) -> float:
        squared_error = info["energy_error"] ** 2
        return -self.weight * squared_error / (1.0 + squared_error)

    def reset(self, **kwargs):
        observation, info = self.env.reset(**kwargs)
        self.previous_potential = self.potential(info)
        return observation, info

    def step(self, action):
        observation, reward, terminated, truncated, info = self.env.step(action)
        # SB3 bootstraps through timeouts and uses zero future value at termination.
        successor = 0.0 if terminated else self.potential(info)
        shaping = self.gamma * successor - self.previous_potential
        self.previous_potential = successor
        return observation, reward + shaping, terminated, truncated, info


def teacher_bounds(config):
    return TEACHER_BOUNDS_1A if config.max_current == 1.0 else TEACHER_BOUNDS


def teacher_examples(config, seed):
    """Supervise on near-upright states and their held-current recovery trajectories."""
    rng = np.random.default_rng(seed)
    plant = FurutaPendulum(config.sample_time)
    teacher = LQRController(config.max_current)
    observations, commands = [], []
    bounds = teacher_bounds(config)

    for error in rng.uniform(-bounds, bounds, size=(192, 4)):
        plant.reset(error + [0.0, np.pi, 0.0, 0.0])
        for _ in range(24):
            state = plant.x.copy()
            state[1] = upright_error(state)
            if np.any(np.abs(state) > bounds):
                break
            action = teacher.current(plant.x) / config.max_current
            # The memoryless teacher's target is valid across previous commands.
            previous = float(rng.uniform(-0.25, 0.25))
            observations.append(observation_from_plant(plant, config, previous))
            commands.append([action])
            for _ in range(config.action_repeat):
                plant.step(action * config.max_current)

    # The policy architecture supplies the exact mirrored examples.
    return np.asarray(observations), np.asarray(commands, dtype=np.float32)


class LQRTeaching(BaseCallback):
    """Add local LQR supervision to each actor update made by stock SAC."""

    def __init__(self, config, seed):
        super().__init__()
        self.seed = seed
        self.observations, self.targets = teacher_examples(config, seed)
        plant = FurutaPendulum(config.sample_time)
        teacher = LQRController(config.max_current)
        upright = np.array([0.0, np.pi, 0.0, 0.0])
        self.slope_observations, self.slope_targets = [], []
        for offset in np.diag(np.append(TEACHER_BOUNDS, 0.25)) * SLOPE_FRACTION:
            plant.reset(upright + offset[:4])
            self.slope_observations.append(observation_from_plant(plant, config, offset[4]))
            self.slope_targets.append([teacher.current(plant.x) / config.max_current])

    def loss(self) -> torch.Tensor:
        index = torch.randint(
            len(self.observations), (TEACHER_BATCH,),
            generator=self.rng, device=self.model.device,
        )
        observations = torch.cat((self.teacher_obs[index], self.slope_obs))
        actions = self.model.actor(observations, deterministic=True)
        local, slope = actions.split((TEACHER_BATCH, len(self.slope_observations)))
        local_mse = torch.nn.functional.mse_loss(local, self.teacher_actions[index])
        slope_mse = torch.nn.functional.mse_loss(slope, self.slope_actions) / SLOPE_FRACTION**2
        return local_mse + slope_mse

    def _on_training_start(self):
        device = self.model.device
        self.rng = torch.Generator(device=device).manual_seed(self.seed)
        self.teacher_obs = torch.as_tensor(self.observations, device=device)
        self.teacher_actions = torch.as_tensor(self.targets, device=device)
        self.slope_obs = torch.as_tensor(np.asarray(self.slope_observations), device=device)
        self.slope_actions = torch.as_tensor(self.slope_targets, dtype=torch.float32, device=device)
        optimizer = self.model.actor.optimizer
        for _ in range(PRETRAIN_UPDATES):
            optimizer.zero_grad(set_to_none=True)
            loss = self.loss()
            loss.backward()
            optimizer.step()
        self.logger.record("teacher/pretrain_loss", loss.item())
        self.hook = optimizer.register_step_pre_hook(self.add_teacher_gradient)

    def add_teacher_gradient(self, optimizer, args, kwargs):
        parameters = [p for p in self.model.actor.parameters() if p.requires_grad]
        with torch.enable_grad():
            loss = self.loss()
            gradients = torch.autograd.grad(
                TEACHER_LOSS_WEIGHT * loss, parameters, allow_unused=True,
            )
        for param, grad in zip(parameters, gradients):
            if grad is not None:
                if param.grad is None:
                    param.grad = grad
                else:
                    param.grad.add_(grad)
        if self.model.num_timesteps % 64 == 0:
            self.logger.record("teacher/local_loss", loss.detach().item())

    def _on_step(self) -> bool:
        return True

    def _on_training_end(self):
        self.hook.remove()


class DeterministicActor(torch.nn.Module):
    """The saved controller needs only the learned deterministic actor layers."""

    def __init__(self, actor: ReflectedActor):
        super().__init__()
        self.latent = deepcopy(actor.latent_pi)
        self.mean = deepcopy(actor.mu)
        self.register_buffer("reflection", actor.reflection.clone())

    def forward(self, observation: torch.Tensor) -> torch.Tensor:
        pair = torch.stack((observation, observation * self.reflection))
        direct, mirror = self.mean(self.latent(pair)).unbind(0)
        return torch.tanh((direct - mirror) * 0.5)


def local_diagnostics(controller: DeterministicActor, config) -> dict:
    """Finite differences of the exported actor and its nonlinear held-current map."""
    plant = FurutaPendulum(config.sample_time)
    upright = np.array([0.0, np.pi, 0.0, 0.0])

    def transition(point):
        plant.reset(upright + point[:4])
        observation = observation_from_plant(plant, config, point[4])
        with torch.no_grad():
            action = controller(torch.from_numpy(observation).unsqueeze(0)).item()
        for _ in range(config.action_repeat):
            plant.step(config.max_current * action)
        state = plant.x.copy()
        state[1] = upright_error(state)
        return np.append(state, action)

    step = 1e-4
    axes = np.eye(5) * step
    closed_loop = np.column_stack([
        (transition(axis) - transition(-axis)) / (2 * step) for axis in axes
    ])
    poles = np.linalg.eigvals(closed_loop)
    return {
        "state_order": ["arm_angle", "upright_error", "arm_velocity", "pendulum_velocity", "previous_normalized_action"],
        "equilibrium_current_A": config.max_current * transition(np.zeros(5))[-1],
        "actor_current_jacobian": (config.max_current * closed_loop[-1]).tolist(),
        "teacher_current_jacobian": [*(-LQRController(config.max_current).gain), 0.0],
        "closed_loop_poles": [{"real": float(p.real), "imag": float(p.imag)} for p in poles],
        "spectral_radius": float(np.max(np.abs(poles))),
        "finite_difference_step": step,
    }


def export_actor(model_path: Path, output_path: Path, config) -> dict:
    actor = SAC.load(model_path, device="cpu").actor
    controller = DeterministicActor(actor).eval()
    with torch.no_grad():
        exported = torch.export.export(
            controller, (torch.zeros(2, len(REFLECTION)),),
            dynamic_shapes=({0: torch.export.Dim("batch", min=1)},),
        )
    torch.export.save(exported, output_path)
    return local_diagnostics(controller, config)


def train_guided(config, run_dir, *, energy_weight, **options):
    """Train the fresh guided variant with unshaped validation and stock SAC."""
    settings = algorithm_settings(config, **options)
    settings["guided"] = {
        "energy_weight": energy_weight,
        "reflection": list(REFLECTION),
        "teacher": "centered held-current LQR",
        "teacher_gain_ampere": LQRController(config.max_current).gain.tolist(),
        "teacher_bounds": teacher_bounds(config).tolist(),
        "slope_state_bounds": TEACHER_BOUNDS.tolist(),
        "pretrain_updates": PRETRAIN_UPDATES,
        "teacher_loss_weight": TEACHER_LOSS_WEIGHT,
        "slope_fraction": SLOPE_FRACTION,
    }
    settings["provenance"] = runtime_provenance()
    run_dir.mkdir()
    atomic_write_json(run_dir / "config.json", asdict(config))
    atomic_write_json(run_dir / "training.json", settings)

    training = Monitor(
        EnergyShaping(FurutaSwingUpEnv(config), settings["gamma"], energy_weight),
        filename=str(run_dir / "training"), info_keywords=MONITOR_KEYS,
    )
    validation = Monitor(FurutaSwingUpEnv(config), info_keywords=MONITOR_KEYS)
    try:
        model = SAC(
            ReflectedPolicy, training, seed=settings["seed"],
            learning_rate=settings["learning_rate"], buffer_size=settings["buffer_size"],
            learning_starts=settings["learning_starts"], batch_size=settings["batch_size"],
            gamma=settings["gamma"], tau=settings["tau"], train_freq=settings["train_frequency"],
            gradient_steps=settings["gradient_steps"], target_update_interval=settings["target_update_interval"],
            ent_coef=settings["entropy_coefficient"], target_entropy=settings["target_entropy"],
            policy_kwargs={"net_arch": {"pi": settings["actor_network"], "qf": settings["critic_network"]}},
            tensorboard_log=str(run_dir / "tensorboard"), device="cuda", verbose=1,
        )
        if model.device.type != "cuda":
            raise RuntimeError("Guided SAC requires CUDA.")
        callbacks = [
            LQRTeaching(config, settings["seed"]),
            CheckpointCallback(settings["checkpoint_frequency"], str(run_dir / "checkpoints"), name_prefix="sac"),
            SuccessFirstEvalCallback(
                validation, reset_seed=settings["evaluation_seed"], best_model_save_path=str(run_dir / "best"),
                log_path=str(run_dir / "evaluation"), eval_freq=settings["evaluation_frequency"],
                n_eval_episodes=settings["evaluation_episodes"], deterministic=True, warn=False,
            ),
            ResumeStateCallback(settings["resume_snapshot_frequency"], run_dir / "resume", verbose=1),
        ]
        model.learn(settings["total_timesteps"], callback=callbacks, progress_bar=True)
        save_committed_state(model, run_dir / "final")
        settings["final_num_timesteps"] = int(model.num_timesteps)
        settings["final_replay_buffer_size"] = int(model.replay_buffer.size())
        settings["device"] = str(model.device)
        local = export_actor(run_dir / "best/best_model.zip", run_dir / "actor.pt2", config)
        atomic_write_json(run_dir / "local_diagnostics.json", local)
        atomic_write_json(run_dir / "training.json", settings)
    finally:
        training.close()
        validation.close()
